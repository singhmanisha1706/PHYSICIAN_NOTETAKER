# Physician Notetaker: Medical Intelligence System

A production-grade AI system for processing physician-patient conversations.

## Features
1.  **Medical Summarization**: Extracts symptoms, diagnoses, and treatments.
2.  **Sentiment/Intent Analysis**: Detects patient anxiety and reassurance seeking.
3.  **SOAP Note Generation**: Auto-generates structured clinical notes.

## Installation

```bash
# 1. Install Dependencies
pip install spacy transformers torch scikit-learn fastapi uvicorn pydantic

# 2. Download Spacy Models
python -m spacy download en_core_web_sm
# Optional: For better medical NER
python -m spacy download en_core_sci_lg
```

## Running the System

### CLI Demo
Run the sample transcript pipeline:
```bash
python run_pipeline.py
```

### API Server
Start the FastAPI server:
```bash
python src/api.py
```
> API Docs available at http://localhost:8000/docs

## Architecture
- `src/pipeline.py`: Main logic class `MedicalPipeline`.
- `src/api.py`: FastAPI web server.
- `run_pipeline.py`: Command line interface.
