
import os
import sys

# Instructions for the user:
# This project requires several advanced NLP libraries.
# Please install them using:
# pip install spacy transformers torch scikit-learn
# python -m spacy download en_core_web_sm
# python -m spacy download en_core_sci_lg  <-- (Optional: For advanced medical NER)
#
# Note: Since the user environment might not have the heavy models (en_core_sci_lg, Bio_ClinicalBERT),
# this code is designed to fallback to `en_core_web_sm` and standard BERT/distilBERT if others are missing,
# ensuring the code runs for demonstration purposes.

import spacy
try:
    from transformers import pipeline, AutoTokenizer, AutoModelForSequenceClassification, AutoModelForSeq2SeqLM
    TRANSFORMERS_AVAILABLE = True
except ImportError:
    TRANSFORMERS_AVAILABLE = False
    print("Warning: 'transformers' library not found or failed to load. Using fallback logic.")
except Exception as e:
    TRANSFORMERS_AVAILABLE = False
    print(f"Warning: Error loading 'transformers': {e}")

import torch
import json
from typing import List, Dict, Any, Optional

class MedicalPipeline:
    def __init__(self, use_mock_heavy_models=True):
        """
        Initialize the pipeline.
        
        Args:
            use_mock_heavy_models (bool): If True, will try to load lighter models or fallback 
                                          if the heavy bio-medical models are not found.
        """
        print("Initializing Physician Notetaker Pipeline...")
        self.device = 0 if torch.cuda.is_available() else -1
        self.transformers_ok = TRANSFORMERS_AVAILABLE

        
        # 1. Load NER Model
        # Try loading the scientific model, fallback to small English model
        try:
            print("Loading NER model (en_core_sci_lg)...")
            self.nlp = spacy.load("en_core_sci_lg")
        except OSError:
            print("Warning: 'en_core_sci_lg' not found. Falling back to 'en_core_web_sm'.")
            print("Please run: python -m spacy download en_core_sci_lg")
            try:
                self.nlp = spacy.load("en_core_web_sm")
            except OSError:
                 # If even small model is missing, download it? Or fail.
                 # Assuming user has at least what was in the original notetaker.py
                 print("Error: Spacy model not found.")
                 sys.exit(1)

        if self.transformers_ok:
            print("Loading Sentiment Analysis model...")
            try:
                # attempting a clinical extraction if available, else standard
                self.sentiment_pipe = pipeline("sentiment-analysis", model="distilbert-base-uncased-finetuned-sst-2-english", device=self.device)
                # Logic: We will map standard positive/negative to Reassured/Anxious for the demo fallback
            except Exception as e:
                print(f"Error loading sentiment model: {e}")
                self.sentiment_pipe = None
        else:
            self.sentiment_pipe = None

        if self.transformers_ok:
            print("Loading SOAP Generation model (flan-t5-base)...")
            try:
                # We use flan-t5-base as it is reasonably sized and good at instructions
                self.soap_generator = pipeline("text2text-generation", model="google/flan-t5-base", device=self.device)
            except Exception as e:
                print(f"Warning: Could not load SOAP generator: {e}. Using rule-based fallback.")
                self.soap_generator = None
        else:
            self.soap_generator = None

        print("Pipeline Iteration Logic Ready.\n")

    def process_transcript(self, transcript: str) -> Dict[str, Any]:
        """
        Main entry point for processing a transcript.
        """
        # A. NER & Summarization
        med_summary = self._extract_medical_summary(transcript)
        
        # B. Sentiment & Intent
        sentiment_data = self._analyze_sentiment_and_intent(transcript)
        
        # C. SOAP Note
        soap_note = self._generate_soap_note(transcript, med_summary)
        
        return {
            "medical_summary": med_summary,
            "sentiment_and_intent": sentiment_data,
            "soap_note": soap_note
        }

    def _extract_medical_summary(self, text: str) -> Dict[str, Any]:
        """
        Uses Spacy NER to extract entities and structure them.
        """
        doc = self.nlp(text)
        
        # Simple heuristic mapping since generic NER doesn't label "Symptom" perfectly without fine-tuning
        # In a real 'en_core_sci_lg', entities are ENTITY. 
        # We will use keyword matching + entity extraction for the demo logic.
        
        symptoms = set()
        treatments = set()
        diagnosis = set()
        
        # Keyword lists for fallback enhancement
        symptom_keywords = ["pain", "ache", "discomfort", "stiffness", "trouble sleeping", "anxiety"]
        treatment_keywords = ["physiotherapy", "painkillers", "medication", "surgery", "exercises"]
        diagnosis_keywords = ["whiplash", "fracture", "strain", "sprain", "concussion"]

        for ent in doc.ents:
            # In sci models, label might be ENTITY
            s_text = ent.text.lower()
            if any(k in s_text for k in symptom_keywords):
                symptoms.add(ent.text)
            elif any(k in s_text for k in treatment_keywords):
                treatments.add(ent.text)
            elif any(k in s_text for k in diagnosis_keywords):
                diagnosis.add(ent.text)
        
        # Also check noun chunks if no entities found (fallback for basic model)
        if not symptoms and not treatments:
            for chunk in doc.noun_chunks:
                s_text = chunk.text.lower()
                if any(k in s_text for k in symptom_keywords):
                    symptoms.add(chunk.text)
                if any(k in s_text for k in treatment_keywords):
                    treatments.add(chunk.text)
                if any(k in s_text for k in diagnosis_keywords):
                    diagnosis.add(chunk.text)

        return {
            "Patient_Name": "Jane Doe", # Placeholder - requires proper PII extraction
            "Symptoms": list(symptoms) if symptoms else ["Not stated"],
            "Diagnosis": list(diagnosis)[0] if diagnosis else "Under investigation",
            "Treatment": list(treatments) if treatments else ["None explicitly mentioned"],
            "Current_Status": "See SOAP note",
            "Prognosis": "See SOAP note"
        }

    def _analyze_sentiment_and_intent(self, text: str) -> Dict[str, str]:
        """
        Analyzes the patient's tone.
        """
        if not self.sentiment_pipe:
            return {"Sentiment": "Unknown", "Intent": "Unknown"}
            
        # We should ideally split by speaker, but we'll analyze the whole chunk or just patient parts if parsed.
        # For this demo, we analyze the whole text (simplified).
        # Truncate to 512 tokens
        result = self.sentiment_pipe(text[:512])[0]
        
        # Map standard labels to our clinical labels
        label = result['label']
        score = result['score']
        
        if label == "NEGATIVE":
            sentiment = "Anxious/Concerned"
            intent = "Expressing symptoms/seeking help"
        else:
            sentiment = "Reassured/Neutral"
            intent = "Reporting progress"
            
        return {
            "Sentiment": sentiment,
            "Intent": intent,
            "Model_Confidence": f"{score:.2f}"
        }

    def _generate_soap_note(self, transcript: str, med_summary: Dict) -> Dict[str, Any]:
        """
        Generates the SOAP note using GenAI (Flan-T5) or Rules.
        """
        # 1. Subjective
        # Construct a prompt for the model
        if self.soap_generator:
            try:
                # One-shot prompting for structure
                prompt = (
                    "Generate a medical SOAP note (Subjective, Objective, Assessment, Plan) for this transcript:\n\n"
                    f"{transcript}\n\n"
                    "SOAP Note:"
                )
                generated = self.soap_generator(prompt, max_length=512, do_sample=False)[0]['generated_text']
                
                # If the model output is just a blob, we might want to try to parse it or just return it.
                # Since Flan-T5 base might produce a short string, we'll use a hybrid approach.
                # For robust structured JSON, we often need a larger model or strict regex parsing.
                # Here we will populate the JSON based on the summary + generated text.
                
                # fallback for structure
                subjective = generated 
            except Exception as e:
                print(f"Generation failed: {e}")
                subjective = "Generation error."
        else:
            subjective = f"Patient presents with {', '.join(med_summary['Symptoms'])}."

        # 2. Objective (Rule based mock)
        objective = {
            "Physical_Exam": "Full range of motion noted " if "full range" in transcript.lower() else "Not documented",
            "Observations": " No acute distress."
        }

        # 3. Assessment
        assessment = {
            "Diagnosis": med_summary['Diagnosis'],
            "Severity": "Moderate" if len(med_summary['Symptoms']) > 2 else "Mild"
        }

        # 4. Plan
        plan = {
            "Treatment": med_summary['Treatment'],
            "Follow_Up": "As needed"
        }

        return {
            "Subjective": subjective, # In a real app, we'd parse this further
            "Objective": objective,
            "Assessment": assessment,
            "Plan": plan
        }

if __name__ == "__main__":
    # Test Run
    transcript_sample = """
    Physician: Good morning, Ms. Jones. How are you feeling?
    Patient: I have a lot of neck pain after the accident.
    Physician: I see. We will prescribe some painkillers and physiotherapy.
    """
    
    pipeline_obj = MedicalPipeline()
    result = pipeline_obj.process_transcript(transcript_sample)
    print(json.dumps(result, indent=2))
