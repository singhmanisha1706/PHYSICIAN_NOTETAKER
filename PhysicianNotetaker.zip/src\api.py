
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional
import uvicorn
import os
import sys

# Add src to path so we can import pipeline
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from pipeline import MedicalPipeline

app = FastAPI(title="Physician Notetaker API", version="1.0")

# Initialize Pipeline (Global to avoid reloading models per request)
# Set use_mock_heavy_models=True to ensure it runs even without 5GB+ bio models downloaded
pipeline_instance = MedicalPipeline(use_mock_heavy_models=True)

class TranscriptRequest(BaseModel):
    transcript: str
    patient_id: Optional[str] = None

@app.get("/")
def read_root():
    return {"status": "System Online", "model_status": "Loaded"}

@app.post("/analyze")
def analyze_transcript(request: TranscriptRequest):
    if not request.transcript:
        raise HTTPException(status_code=400, detail="Transcript cannot be empty")
    
    try:
        results = pipeline_instance.process_transcript(request.transcript)
        return results
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    print("Starting API Server...")
    uvicorn.run(app, host="0.0.0.0", port=8000)
