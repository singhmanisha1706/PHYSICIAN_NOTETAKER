
import sys
import os

# Ensure src is in pythonpath
sys.path.append(os.path.join(os.path.dirname(__file__), "src"))

from pipeline import MedicalPipeline
import json

def main():
    print(">>> Loading Physician Notetaker Main Interface...")
    
    # 1. Initialize
    try:
        pipe = MedicalPipeline()
    except Exception as e:
        print(f"CRITICAL ERROR: Failed to initialize pipeline. {e}")
        return

    # 2. Sample Data
    sample_transcript = """
    Physician: Good morning, Ms. Jones. How are you feeling today?
    Patient: Good morning, doctor. I’m doing better, but I still have some discomfort now and then.
    Physician: I understand you were in a car accident last September. Can you walk me through what happened?
    Patient: Yes, it was on September 1st. I was driving and another car hit me from behind.
    Physician: What did you feel immediately after?
    Patient: I felt pain in my neck and back almost right away.
    Physician: Did you seek medical attention?
    Patient: Yes, I went to A&E. They said it was a whiplash injury.
    Physician: How did things progress?
    Patient: The first four weeks were rough. I had to take painkillers regularly. I also did ten sessions of physiotherapy.
    Physician: Are you still experiencing pain now?
    Patient: It’s not constant, but I do get occasional backaches.
    Physician: Everything looks good. Your neck and back have a full range of movement.
    """

    print("\n>>> Processing Sample Transcript...\n")
    
    # 3. Run
    results = pipe.process_transcript(sample_transcript)
    
    # 4. Output
    print("\n========== FINAL REPORT ==========\n")
    print(json.dumps(results, indent=2))
    print("\n==================================")

if __name__ == "__main__":
    main()
