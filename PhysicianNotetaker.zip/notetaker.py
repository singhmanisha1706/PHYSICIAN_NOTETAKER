import json
import spacy
from transformers import pipeline

print("Loading NLP models...")

nlp = spacy.load("en_core_web_sm")
sentiment_model = pipeline("sentiment-analysis")

print("Models loaded successfully.\n")

TRANSCRIPT = """
Patient reports neck and back pain after a car accident.
Diagnosed with whiplash injury.
Underwent ten physiotherapy sessions.
Currently experiencing occasional back pain.
Full recovery expected within six months.
"""

def extract_medical_entities(text):
    symptoms = []
    treatments = []
    diagnosis = []

    doc = nlp(text)

    for sent in doc.sents:
        s = sent.text.lower()
        if "pain" in s:
            symptoms.append(sent.text.strip())
        if "physiotherapy" in s:
            treatments.append(sent.text.strip())
        if "whiplash" in s:
            diagnosis.append(sent.text.strip())

    return {
        "Symptoms": list(set(symptoms)),
        "Treatment": list(set(treatments)),
        "Diagnosis": list(set(diagnosis))
    }
#generate medical summary
def generate_medical_summary(entities):
    return {
        "Patient_Name": "Janet Jones",
        "Symptoms": entities["Symptoms"],
        "Diagnosis": entities["Diagnosis"][0] if entities["Diagnosis"] else "Unknown",
        "Treatment": entities["Treatment"],
        "Current_Status": "Occasional back pain",
        "Prognosis": "Full recovery expected within six months"
    }

def analyze_sentiment(text):
    result = sentiment_model(text)[0]
    label = result["label"]

    if label == "NEGATIVE":
        return {
            "Sentiment": "Anxious",
            "Intent": "Seeking reassurance"
        }
    else:
        return {
            "Sentiment": "Reassured",
            "Intent": "Reporting recovery"
        }

def generate_soap_note():
    return {
        "Subjective": {
            "Chief_Complaint": "Neck and back pain",
            "History_of_Present_Illness": "Patient experienced whiplash injury after car accident."
        },
        "Objective": {
            "Physical_Exam": "Full range of motion in neck and back, no tenderness."
        },
        "Assessment": {
            "Diagnosis": "Whiplash injury",
            "Severity": "Mild and improving"
        },
        "Plan": {
            "Treatment": "Physiotherapy and pain management",
            "Follow_Up": "Return if symptoms worsen"
        }
    }

if __name__ == "__main__":
    print("----- PHYSICIAN NOTETAKER OUTPUT -----\n")

    entities = extract_medical_entities(TRANSCRIPT)
    summary = generate_medical_summary(entities)
    sentiment = analyze_sentiment("I still have some back pain and I am worried.")
    soap = generate_soap_note()

    print("MEDICAL SUMMARY")
    print(json.dumps(summary, indent=2))

    print("PATIENT SENTIMENT & INTENT")
    print(json.dumps(sentiment, indent=2))

    print("SOAP NOTE")
    print(json.dumps(soap, indent=2))

    print("----- END OF REPORT -----")
